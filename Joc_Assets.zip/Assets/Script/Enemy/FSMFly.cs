using UnityEngine;
[RequireComponent (typeof(Rigidbody2D))]
public class FSMFly : MonoBehaviour
{
    enum FlyStates
    {
        Move,
        Attack
    }

    private Rigidbody2D _rigidbody;
    public float speed = 3.0f;
    [SerializeField] Vector2 direction = new Vector2(1, 0.25f);

    [SerializeField] LayerMask Ground;
    public Transform UpPoint;
    public Transform LateralPoint;
    public Transform DownPoint;
    bool upHit, lateralHit, downHit;

    public static Transform Player;
    float attackDistance = 10.0f;
    float stopDistance = 5.0f;
    float timerToShoot;
    public float radiusDetectWalls = 0.25f;

    FSM<FlyStates> brain;
    public Bullet bullet;
    float _elapsedTime = 0f;
    float _ratioShoot = 1f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _rigidbody = GetComponent<Rigidbody2D>();
        InitFSM();
    }

    // Update is called once per frame
    void Update()
    {
        brain.Update();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag != "Player") {return;}
        collision.gameObject.SetActive(false);
    }

    public void InitFSM() 
    { 
        brain = new FSM<FlyStates>(FlyStates.Move);
        brain.SetOnEnter(FlyStates.Move, () => timerToShoot = 0f);
        brain.SetOnEnter(FlyStates.Attack, () => { });
        brain.SetOnStay(FlyStates.Move, MoveUpdate);
        brain.SetOnStay(FlyStates.Attack, AttackUpdate);
    }

    public void AttackUpdate() 
    { 
        direction = Player.position - transform.position;
        direction.Normalize();
        _rigidbody.linearVelocity = direction * speed;
        /*_elapsedTime+=Time.deltaTime;
        if (_elapsedTime > _ratioShoot)
        {
            _elapsedTime = 0f;
            Bullet currentBullet = Instantiate(bullet, transform.position, Quaternion.identity);
            currentBullet.dir = direction;
        }*/
    }

    public void MoveUpdate() 
    { 
        _rigidbody.linearVelocity = direction * speed;

        if (DetecCollision())
        {
            ChangeDirection();
        }

        if (IsPlayerCloseByDistance())
        {
            brain.ChangeState(FlyStates.Attack);
        }

    }

    bool DetecCollision() 
    {
        upHit = Physics2D.OverlapCircle(UpPoint.transform.position, radiusDetectWalls, Ground);
        downHit = Physics2D.OverlapCircle(DownPoint.transform.position, radiusDetectWalls, Ground);
        lateralHit = Physics2D.OverlapCircle(LateralPoint.transform.position, radiusDetectWalls, Ground);

        return upHit || downHit || lateralHit;
    }

    void ChangeDirection()
    {
        if (lateralHit)
        {
            transform.Rotate(0, 180, 0);
            direction.x = -direction.x;
        }

        if (upHit && direction.y > 0)
        {
            direction.y = -direction.y;
        }

        if (downHit && direction.y < 0)
        {
            direction.y = -direction.y;
        }

    }

    bool IsPlayerCloseByDistance()
    {
        if (Vector2.Distance(transform.position, Player.position) <= attackDistance)
        {
            return true;
        }
        return false;
    }

    public static void setPlayer(Transform playerTransform){
        Player = playerTransform;
    }
}