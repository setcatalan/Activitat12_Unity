using UnityEngine;
using UnityEngine.InputSystem;
public class BasicMove : MonoBehaviour
{
    public GameObject attackPrefab;
    Rigidbody2D body;
    [SerializeField] float velocity = 2f;
    [SerializeField] float jumpForce = 2f;
    bool grounded;
    InputSystem_Actions _playerInput;
    InputAction _move;
    InputAction _jump;
    InputAction _attack;
    Vector2 _inputDir;
    bool _jumpHeld;
    bool _attackHeld;
    public float timeToAttack = 2f;
    float timeBeforeAttack = 0f;

    private CheckGround _checkGround;
    private void Awake()
    {
        _playerInput = new InputSystem_Actions();
        _playerInput.Enable();
        _move = _playerInput.Player.Move;
        _jump = _playerInput.Player.Jump;
        _attack = _playerInput.Player.Attack;

        _checkGround = GetComponentInChildren<CheckGround>();
        FSMFly.setPlayer(transform);
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        TryGetComponent<Rigidbody2D>(out body);
 
    }

    private void Update()
    {
        _inputDir = _move.ReadValue<Vector2>();
        _jumpHeld = _jump != null && _jump.IsPressed();
        _attackHeld = _attack != null && _attack.IsPressed();
        timeBeforeAttack -= 0.1f;
    }

    private void FixedUpdate()
    {
        body.linearVelocity = new Vector2(_inputDir.x * velocity, body.linearVelocityY);

        if (_jumpHeld && _checkGround.isGrounded)
        {
            Jump();
        }

        if (_attackHeld && timeBeforeAttack <= 0)
        {
            Attack();
            timeBeforeAttack = timeToAttack;
        }
    }

    public void Jump()
    {
        body.AddForce(Vector2.up * jumpForce);
    }

    public void Attack()
    {
        Vector3 direction;
        if (_inputDir.x == 0f)
        {
            direction = Vector2.right;
        } else direction = _inputDir;

        GameObject attack = Instantiate(attackPrefab, transform.position + direction, Quaternion.identity);
        attack.GetComponent<SlashAttack>().setDirection(direction);
        if (_inputDir.x == 0f)
        {
            attack.GetComponent<SlashAttack>().setVelocity(0f);
        } else attack.GetComponent<SlashAttack>().setVelocity(velocity);
    }
}