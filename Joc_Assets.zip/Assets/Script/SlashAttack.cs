using UnityEngine;

public class SlashAttack : MonoBehaviour
{
    public GameObject coinPrefab;
    private Rigidbody2D rb;
    public float speed;
    float velocity;
    public float timeToDisapear;
    float _elapsedTime = 0f;
    private Vector2 direction;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        rb.linearVelocity = direction * velocity;

        _elapsedTime += Time.deltaTime;

        if (_elapsedTime >= timeToDisapear)
        {
            gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            collision.gameObject.SetActive(false);
            GameObject coin = Instantiate(coinPrefab);

            if (coin.TryGetComponent<Rigidbody2D>(out Rigidbody2D rb))
            {
                rb.position = collision.gameObject.transform.position;
            }
        }
    }

    public void setDirection(Vector2 dir)
    {
        direction = dir;
        if (direction == Vector2.left)
        {
            transform.Rotate(0, 180, 0);
        }
    }

    public void setVelocity(float vel)
    {
        velocity = vel + speed;
    }
}
