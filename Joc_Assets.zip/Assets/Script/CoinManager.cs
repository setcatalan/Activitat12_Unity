using System;
using UnityEngine;
[DefaultExecutionOrder(-100)]

public class CoinManager : MonoBehaviour
{
    private static CoinManager _instance;

    public static CoinManager Instance { get { return _instance; } }
    public static Action OnAddPoint;

    [SerializeField] private float _amount;
    public float Amount {get {return _instance._amount;}}

    private void Awake()
    {
        if (_instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    public static void AddAmount(float amount)
    {
        if (_instance != null)
        {
            Instance.AddAmountInternal(amount);
            OnAddPoint?.Invoke();
        }
    }

    private void AddAmountInternal(float amount)
    {
        _amount += amount;
    }
}
