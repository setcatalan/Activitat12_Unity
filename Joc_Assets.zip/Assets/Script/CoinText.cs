using UnityEngine;
using TMPro;

public class CoinText : MonoBehaviour
{
    TextMeshProUGUI _text;

    private void Start()
    {
        _text = GetComponent<TextMeshProUGUI>();
        ChangeText();
    }

    private void OnEnable()
    {
        CoinManager.OnAddPoint += ChangeText;
    }

    private void OnDisable()
    {
        CoinManager.OnAddPoint -= ChangeText;
    }

    private void ChangeText()
    {
        _text.text = "Coins: " + CoinManager.Instance.Amount;
    }
}
