using UnityEngine;

public class SpawnerEnemy : MonoBehaviour
{
    float _elapsedTime = 0f;
    public float _spawnTime = 0.2f;
    int _spawnCount = 0;
    public int _quantityToSpawn = 20;
    public GameObject prefabToSpawn;

    Transform[] spawnPoints = new Transform[5];
    public Transform spawnPoint1;
    public Transform spawnPoint2;
    public Transform spawnPoint3;
    public Transform spawnPoint4;
    public Transform spawnPoint5;
    
    void Start()
    {
        spawnPoints[0] = spawnPoint1;
        spawnPoints[1] = spawnPoint2;
        spawnPoints[2] = spawnPoint3;
        spawnPoints[3] = spawnPoint4;
        spawnPoints[4] = spawnPoint5;
    }

    // Update is called once per frame
    void Update()
    {
        if (_spawnCount >= _quantityToSpawn) {return;}

        _elapsedTime += Time.deltaTime;

        if (_elapsedTime >= _spawnTime)
        {
            int numAleatori = Random.Range(0,5);

            _elapsedTime = 0f;
            GameObject spawnedPrefab = Instantiate(prefabToSpawn);

            if (spawnedPrefab.TryGetComponent<Rigidbody2D>(out Rigidbody2D rb))
            {
                rb.position = spawnPoints[numAleatori].position;
                _spawnCount++;
            }
        }
    }
}
